Video and Image labeling tool for YOLO
https://github.com/enisgetmez
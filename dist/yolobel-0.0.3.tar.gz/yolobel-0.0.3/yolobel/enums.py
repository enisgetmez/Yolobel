input_vid = 0
out_count = 0
out_directory = 0
out_name = 0
yolo_result = 0